import React, { useEffect, useState } from "react";

const axios = require("axios").default;

function Animais() {
  return <div className="animais"></div>;
}

export default Animais;
